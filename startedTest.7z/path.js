module.exports = {
    folder_app          : 'app',
    folder_configs      : 'configs',
    folder_routers      : 'routers',
    folder_models       : 'models',
    folder_controllers  : 'controllers',
    folder_schemas      : 'schemas',
    folder_validates    : 'validates',
    folder_services     : 'services',
    folder_commons      : 'commons',
}